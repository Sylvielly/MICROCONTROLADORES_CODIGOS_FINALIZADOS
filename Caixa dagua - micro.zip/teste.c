//Programa caixa d'agua

#include <18f4550.h>
//noprotect permite capturar programa pelo pic
//hs acima de 8mhz, na utliza��o do cristal externo
//nowdt testa se est� pedindo para executar alguma coisa(c�o de guarda)
//nomclr para utilizar o clock interno
//nolvp ele precisa de alta tens�o aplicado no master clear(barrado)
#fuses hs,nowdt,noprotect,nolvp,NOMCLR
#define A 0xF81.0  //A � igual ao pino zero da porta B(F81)
#define B 0xF81.1  //B � igual ao pino um da porta B(F81)
#define C 0xF83.0  //C � igual ao pino zero da porta D(F83)


void main() {

#asm  
//------W recebe valor e passa para o FF1 que � INCON2-------------------------
   //S� a porta B tem registrador de PULL-UP
 movlw  0x00  // 00h= pullup habilitado;80h=pullup desabilitado.
 movwf  0xFF1 //intcon2=00h
//-----------------------------------------------------------------------------

// A e B j� est�o setados como 1

//--W recebe a configura��o dos pinos para entrada e passa para F93 que � o TRISB--
 movlw  0xFF  //w=11111111b
 movwf  0xF93  //trisbB=11111111b
//-----------------------------------------------------------------------------

//--W recebe a configura��o dos pinos para saida e passa para F95 que � TRISD--
 movlw  0x00 //w=00000000b
 movwf  0xF95 // trisD=00000000b 
//-----------------------------------------------------------------------------

movlw  0xE6 //w=11100110b
movwf  0xFD3


L0:
   BTFSC A  //Se A for zero(condi��o 0 = Caixa cheia[bot�o apertado] / condi��o 1 = caixa vazia[bot�osolto])
   GOTO L1
   BTFSC B  //Se B for zero(condi��o 0 = Caixa cheia[bot�o apertado] / condi��o 1 = caixa vazia[bot�osolto])
   GOTO L1
   BCF C    //Se A e B for zero[caixa cheia], C � restado para 0(desliga valvula)
   GOTO L2

L1: 
   BTFSS A  //Se A for um (condi��o 0 = Caixa cheia[bot�o apertado] / condi��o 1 = caixa vazia[bot�osolto]
   GOTO L2
   BTFSS B  //Se B for um(condi��o 0 = Caixa cheia[bot�o apertado] / condi��o 1 = caixa vazia[bot�osolto])
   GOTO L2
   BSF C //Se A ou B for um, C � setado para 1(liga valvula) 
   
L2: // Reiniciar LOOP
   GOTO L0

#endasm
}

