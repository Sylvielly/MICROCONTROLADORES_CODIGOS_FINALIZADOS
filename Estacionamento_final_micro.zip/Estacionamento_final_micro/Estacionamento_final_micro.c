#include <18f4550.h>
//noprotect permite capturar programa pelo pic
//hs acima de 8mhz, na utliza��o do cristal externo
//nowdt testa se est� pedindo para executar alguma coisa(c�o de guarda)
//nomclr para utilizar o clock interno
//nolvp ele precisa de alta tens�o aplicado no master clear(barrado)
#fuses hs,nowdt,noprotect,nolvp,NOMCLR
#define BTN 0xF81.0  //A � igual ao pino zero da porta B(F81)
#define SENs 0xF81.1  //B � igual ao pino um da porta B(F81)
#define CANC 0xF83.0  //C � igual ao pino zero da porta D(F83)
#define VAG 0xF83.1  //E � igual ao pino um da porta D(F83)
#define MEM 0xF83.2  //D � igual ao pino dois da porta D(F83)
void main(){

int cont = 10;
int delay_reg1;
int delay_reg2;

#asm 

goto inicio

delay_1s:
   movlw 200
   movwf delay_reg1
   movlw 250
   movwf delay_reg2

aux:
   movlw 200         //RECARREGANDO O delay_reg1
   movwf delay_reg1

loop1:               // TEMPO DO CICLO = 4 x 1/FREQU�NCIA   ->   TEMPO DO CICLO = 4 x 1/1000000 = 4us
                     // PARA TERMOS UM ATRASO DE 1s, SER�O NECESS�RIOS 250000 CICLOS DE M�QUINA
                     // TEMPO DESEJADO = 250000*0,000004 = 1s
   
   NOP               // NO OPERATION, UTILIZADO APENAS PARA "GASTAR" 1 CICLO DE M�QUINA
   NOP
   DECFSZ delay_reg1 // 1 CICLO          5 CICLOS * 200 = 1000 CICLOS
   goto loop1        // 2 CICLOS
      
loop2:
   DECFSZ delay_reg2 // 1 CICLO             1000 CICLOS * 250 = 250000 CICLOS NECESS�RIO PARA TERMOS UM ATRASO DE 1S.  
                     //                     N�O FORAM CONSIDERADOS OS 3 CICLOS GASTOS PELO LOOP2
   goto aux          // 2 CICLOS            QUE AO FINAL DAR� UMA DIFEREN�A DE 750 CICLOS. SE MULTIPLICADO POR 4us
   goto exit         //                     TEREMOS UMA DIFEREN�A DE 0,003s ou 3ms

exit:
   BTFSC SENS        //VERIFICA��O AP�S 1s, CASO O SENSOR VOLTE A SER ACIONADO, VOLTE PARA O LA�O DO SENSOR LB
   GOTO  D_CANC      //CASO O SENSOR N�O VOLTE A SER ACIONADO, DESLIGUE A CANCELA
   GOTO  LB
   RETURN

inicio:

//------W recebe valor e passa para o FF1 que � INCON2-------------------------
   //S� a porta B tem registrador de PULL-UP
movlw  0x00  // 00h= pullup habilitado;80h=pullup desabilitado.
movwf  0xFF1 //intcon2=00h
//-----------------------------------------------------------------------------

// A e B j� est�o setados como 1

//--W recebe a configura��o dos pinos para entrada e passa para F93 que � o TRISB--
movlw  0xFF  //w=11111111b
movwf  0xF93  //trisbB=11111111b
//-----------------------------------------------------------------------------

//--W recebe a configura��o dos pinos para saida e passa para F95 que � TRISD--
movlw  0x00 //w=00000000b
movwf  0xF95 // trisD=00000000b 
//-----------------------------------------------------------------------------

movlw  0xC6 //w=11100110b
movwf  0xFD3

VAZIO:
   BSF VAG      //liga led vazio

L0:
   BTFSC BTN    //Se A for zero pula (condi��o 0 = bot�o apertado / condi��o 1 = bot�o solto)
   GOTO  L1
   BSF   CANC   //Se A zero, C � setado para 1(cancela abre)
  
L1:
   BTFSS CANC  //PULA, SE A CANCELA ESTIVER ACIONADA
   GOTO  FIM
   BTFSC SENS  //PULA SE O SENSOR ESTIVER ACIONADO
   GOTO  L1
   GOTO  LB    //CASO O SENSOR ESTEJA ACIONADO, V� PRA LB
   
LB:
   BTFSS SENS     //O PROGRAMA S� IR� SAIR DE LB CASO O SENSOR VOLTE A FICAR DESACIONADO (CARRO PASSOU)
   GOTO  LB
   call  delay_1s //CASO O CARRO PASSE, ESPERE 1s
   
D_CANC:
   BCF      CANC  //DESACIONA A CANCELA
   DECFSZ   CONT  //DECREMENTA A QUANTIDADE DE VAGAS DO ESTACIONAMENTO
   GOTO     inicio//CASO 
   GOTO     CHEIO
   
CHEIO:
   BCF      VAG   //DESLIGA O LED INDICADOR DE VAGAS DO ESTACIONAMENTO
      
FIM:
   GOTO     L0
   
#endasm
}
