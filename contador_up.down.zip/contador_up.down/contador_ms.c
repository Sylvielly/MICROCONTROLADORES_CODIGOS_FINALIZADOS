#define up 0x7C08
#define down 0x7C09

#include <18f4550.h>
#fuses HS,NOWDT, PUT, BROWNOUT, NOLVP, 
#use delay(clock=8000000) 
#byte portE = 0xF84
#byte portD = 0xF83
#byte portA = 0xF80
int digito[10] = { 0b00111111,
                   0b00000110,
                   0b01011011,
                   0b01001111,
                   0b01100110,
                   0b01101101,
                   0b01111101,
                   0b00000111,
                   0b01111111,
                   0b01101111
                };
int16 d1, d2, d3;

#priority int_EXT, int_EXT1
#int_EXT
void interrup_up(){
   if((d1==1)&&(d2==0)&&(d3==0)){
      d1 = 0, d2 = 0, d3 = 0;
   }
   else{
      d3++;
      if(d3>9){
         d3 = 0;
         d2++;
         if(d2>9){
            d2 = 0;
            d1++;
            if(d1>1){
               d1  = 0;
            }
         }
      }
   }
}
#int_EXT1
void interrup_down(){
   if(d3>0){
      d3--;
   }
   else if((d3==0)&&(d2>0)){
      d3=9;
      d2--;
   }
   else if((d3==0)&&(d2==0)&&(d1>0)){
      d3=9;
      d2=9;
      d1--;
   }
   else{
      d1 = 0;
      d2 = 0;
      d3 = 0;
   }             
}
void main(){

   enable_interrupts(GLOBAL);
   enable_interrupts(INT_EXT);
   enable_interrupts(INT_EXT1);
   ext_int_edge(H_TO_L);   

   d1 = 0, d2 = 0, d3 = 0;
   //Desativa display 4
   output_A(0x00);
   
   while(1){
      //centena
      output_D(digito[d1]); //define valor
      output_E(0x01);       //ativa display 1
     
      delay_ms(2);
      
      //dezena
      output_D(digito[d2]); //define valor
      output_E(0x02);       //ativa display 2
      
      delay_ms(2);
      
      //unidade
      output_D(digito[d3]); //define valor
      output_E(0x04);       //ativa display 3
      
      delay_ms(2);

   }
}

