#define reset 0x7C08
#define pause 0x7C09

#include <18f4550.h>
#fuses HS,NOWDT, PUT, BROWNOUT, NOLVP 
#use delay(clock=8000000) 
#byte portE = 0xF84
#byte portD = 0xF83
#byte portA = 0xF80
int digito[10] = { 0b00111111,
                   0b00000110,
                   0b01011011,
                   0b01001111,
                   0b01100110,
                   0b01101101,
                   0b01111101,
                   0b00000111,
                   0b01111111,
                   0b01101111
                };
int16 d1, d2, d3, d4, aux=0;
#priority int_ext, int_ext1, int_timer0

#int_ext
void interrup_R(){
   d1=0;
   d2=0;
   d3=0;
   d4=0;
}
#int_ext1
void interrup_P(){
   aux++;
}
#int_timer0
void _1segundo(){ 
   static unsigned int32 n;
   set_timer0(255+get_timer0());
   n++;   
   if (n==4){
      n=0;
      if((aux%2)==0){
         aux=0;
         d4++;
         if(d4>9){
            d4=0;
            d3++;
            if(d3>5){
               d3=0;
               d2++;
               if(d2>9){
                  d2=0;
                  d1++;
                  if(d1>5){
                     d1=0;
                  }
               }
            }
         }
      }
   }
}
void main(){
   enable_interrupts(GLOBAL|INT_TIMER0);
   enable_interrupts(INT_EXT);
   enable_interrupts(INT_EXT1);
   ext_int_edge(H_TO_L);
   set_timer0(255);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_2);
   
   d1 = 0, d2 = 0, d3 = 0, d4 = 0;
   
   while(1){
      //dezena minuto
      output_D(digito[d1]); //define valor
      OUTPUT_A(0x00);      //desativa display 4
      output_E(0x01);       //ativa display 1
     
      delay_ms(2);
      
      //unidade minuto
      output_D(digito[d2]); //define valor
      output_E(0x02);       //ativa display 2
      
      delay_us(500);
      
      //dezena segundo
      output_D(digito[d3]); //define valor
      output_E(0x04);       //ativa display 3
      
      delay_us(500);
      
      //unidade segundo
      OUTPUT_D(digito[d4]);  //define valor 
      OUTPUT_E(0x00);       //desativa display 3
      OUTPUT_A(0X20);      //ativa display 4
      
      delay_us(500);      
   }


}
